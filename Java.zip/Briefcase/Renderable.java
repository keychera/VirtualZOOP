interface Renderable{
	void Render();
};
