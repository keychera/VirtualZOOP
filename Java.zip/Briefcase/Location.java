class Location{

}
